# Installation Process

1. Access your host through the FTP manager or cPanel File Manager
2. Once connected, access the path @app/modules/addons/modules
3. Upload the 'mysql' folder to the 'modules' folder on your web server.
4. After uploading the files, visit Easy Forms and click the Add-ons link in the navigation bar.
5. You will see your MySQL add-on in the list.

For more information, read the MySQL Add-On documentation on:

- https://docs.easyforms.dev/addon-mysql.html