using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Reflection;
using runnerDotNet;
namespace runnerDotNet
{
	public class EditColorPicker : UserControl
	{
		public EditColorPicker(XVar field, XVar pageObject, XVar id, XVar connection) : base(field, pageObject, id, connection) { }

		public override XVar initUserControl()
		{
			return null;
		}
		
		public override XVar buildUserControl(dynamic value, dynamic mode, dynamic fieldNum, dynamic validate, dynamic additionalCtrlParams, dynamic data)
		{
			MVCFunctions.Echo(
				String.Format(@"{0}<input id=""{1}"" {2} type=""text"" class=""color-picker black"" {3} {4} name=""{5}"" {6} value=""{7}"">",
				getSetting("label"), cfield, inputStyle,
				(mode == Constants.MODE_SEARCH ? "autocomplete=\"off\" " : ""),
				((mode == Constants.MODE_INLINE_EDIT || mode == Constants.MODE_INLINE_ADD) && is508 == true ? "alt=\"" + strLabel.ToString() + "\" " : ""),
				cfield, pageObject.pSetEdit.getEditParams(field), MVCFunctions.htmlspecialchars(value)
			));
				
			return null;
		}
		
		public override XVar getUserSearchOptions()
		{
			return new XVar(0, Constants.EQUALS, 1, Constants.STARTS_WITH, 2, Constants.NOT_EMPTY, 3, Constants.NOT_EQUALS);		
		}

		public override XVar addJSFiles()
		{
			pageObject.AddJSFile("jquery.miniColors.min.js");
			pageObject.AddJSFile("include/js/jquery-migrate-1.2.1.min.js");
			return null;
		}

		public override XVar addCSSFiles()
		{
			pageObject.AddCSSFile("jquery.miniColors.css");
			return null;
		}
	}
}